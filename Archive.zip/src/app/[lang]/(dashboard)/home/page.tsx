export default function Page() {
  return <h1>Home page!</h1>
}
